<?php
/*
Plugin Name: Amerisale Listings
Plugin URI: www.greatinnovus.com
Description: Provides users with better and simple navigation interface.

*/

if (!defined('WP_CONTENT_URL'))
	define('WP_CONTENT_URL', get_option('siteurl') . '/wp-content');
if (!defined('WP_CONTENT_DIR'))
	define('WP_CONTENT_DIR', ABSPATH . 'wp-content');
if (!defined('WP_PLUGIN_URL') )
	define('WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins');
if (!defined('WP_PLUGIN_DIR') )
	define('WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins');
	
if (!class_exists('WPAYnetress')) {
	class WPAYnetress {
		/**
		 * @var string The plugin version
		 */
		var $version = '1.2.3';

		/**
		 * @var string The options string name for this plugin
		 */
		 
		var $optionsName = 'wp_netress_options';

		/**
		 * @var string $localizationDomain Domain used for localization
		 */
		var $localizationDomain = 'Netries-Detail';

		/**
		 * @var string $pluginurl The url to this plugin
		 */
		var $pluginurl = '';
		/**
		 * @var string $pluginpath The path to this plugin
		 */
		var $pluginpath = '';

		/**
		 * @var array $options Stores the options for this plugin
		 */
		var $options = array();
		var $type = 'posts';

		/**
		 * PHP 4 Compatible Constructor
		 */
		function WPAYnetress() {$this->__construct();}

		/**
		 * PHP 5 Constructor
		 */
		function __construct() {
			$name = dirname(plugin_basename(__FILE__));
			//"Constants" setup
			$this->pluginurl = WP_PLUGIN_URL . "/$name/";
			$this->pluginpath = WP_PLUGIN_DIR . "/$name/";

			//Initialize the options
			$this->get_options();

			//Actions
			add_action('admin_menu', array(&$this, 'admin_menu_link'));
		}

		/**
		 * Retrieves the plugin options from the database.
		 * @return array
		 */
		function get_options() {
			if (!$options = get_option($this->optionsName)) {
				$options = array(
					'code' => 'Pages:',
				);
				update_option($this->optionsName, $options);
			}
			$this->options = $options;
		}
		/**
		 * Saves the admin options to the database.
		 */
		function save_admin_options(){
			return update_option($this->optionsName, $this->options);
		}

		/**
		 * @desc Adds the options subpanel Amerisale Listings
		 */
		function admin_menu_link() {
			add_menu_page('Netries-Detail', 'Amerisale Listings', 'manage_options', basename(__FILE__), array(&$this, 'admin_options_page'));
			add_filter('plugin_action_links_' . plugin_basename(__FILE__), array(&$this, 'filter_plugin_actions'), 10, 2 );
		}

		/**
		 * @desc Adds the Settings link to the plugin activate/deactivate page
		 */
		function filter_plugin_actions($links, $file) {
			$settings_link = '<a href="options-general.php?page=' . basename(__FILE__) . '">' . __('Settings', $this->localizationDomain) . '</a>';
			array_unshift($links, $settings_link); // before other links

			return $links;
		}

		/**
		 * Adds settings/options page
		 */
		function admin_options_page() {
			 if (isset($_POST['wp_netries_save'])) {
				if (wp_verify_nonce($_POST['_wpnonce'], 'Netries-Detail-update-options')) {
					echo $this->options['code'] = $_POST['code'];
					$quantity = $_POST['quantity'];
					$item = $_POST['item'];
					$this->save_admin_options();
					echo '<div class="updated"><p>' . __('Success! Your changes were successfully saved!', $this->localizationDomain) . '</p></div>';
				}
				else {
					echo '<div class="error"><p>' . __('Whoops! There was a problem with the data you posted. Please try again.', $this->localizationDomain) . '</p></div>';
				}
			} 
?>

 <style>
	.heading{font-size: 18px; font-weight: bold; text-transform: capitalize;}
	.cont_tab1{width: 100px;}
	.cont_tab2{width: 200px;}
	#example-two ,#example-three{
    background: none repeat scroll 0 0 #EEEEEE;
    box-shadow: 0 0 5px #666666;
    margin: 0 0 20px;
    padding: 10px;
}
.red{color:red;}
.blue{color:blue;}
.black{color:#000;}
 </style>
 
	<link rel="stylesheet" href="<?php echo plugins_url(); ?>/netriesdetail/css/amerisale-re.css">
    <script src='http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js'></script>
    <script src="<?php echo plugins_url(); ?>/netriesdetail/js/organictabs.jquery.js"></script>
    <script>
        $(function() {
            $("#example-one").organicTabs();
            $("#example-two").organicTabs({
                "speed": 200
            });
			
			$('#wp_netries_options').submit(function() {
				  // alert($(this).serialize());
				    $('.list-wrap').html('Progressing..........');
				    $('#example-two').hide();
				    $('#example-three').hide();
				 $.ajax({
				  url: "<?php echo plugins_url(); ?>/netriesdetail/form1.php",
				  data: $(this).serialize()
				}).done(function(res) {  
					// alert(res);
					$('.list-wrap').html(res);
				});
			  return false;
			});
        });
		function sel_list(){
			// alert('TEst');
			var ids = $('#Select1').val();
			// alert(ids);
			if(ids == null){
				alert('Please Select any one of the Agent!....');
				return false;
			}else{
			$('#example-one').hide();
			$('#example-three').hide();
			ids = ids.toString();
			var mySplitResult = ids.split("~");
			$.ajax({
				 url: "<?php echo plugins_url(); ?>/netriesdetail/viewdetail.php",
				  data: 'data='+mySplitResult[0],
				}).done(function(res) { 
					if(res == 'There is no records in this Agent.'){
						alert('There is no records in this Agent.');
						return false;
					}else{
						$('.list-wraps').html(res);
					}
				});
			}
		}
		
		function edit_list(){
			// alert('TEst');
			var ids = $('#Select1').val();
			// alert(ids);
			if(ids == null){
				alert('Please Select any one of the Agent!....');
				return false;
			}else{
			$('.list-wraps').html('Progressing..........');
				ids = ids.toString();
			var mySplitResult = ids.split("~");
			$('#example-one').hide();
			$('#example-three').hide();
			$.ajax({
				  url: "<?php echo plugins_url(); ?>/netriesdetail/form.php",
				  data: 'agent='+'1~'+mySplitResult[0],
				}).done(function(res) { 
					if(res == 'There is no records in this Agent.'){
						alert('There is no records in this Agent.');
						location.reload();
						return false;
					}else{
						$('.list-wraps').html(res);
					}
				});
			}
		}
		
		function change_cat(){
			var ids = $('#Select1').val();
			if(ids == null){
				alert('Please Select any one of the Agent!....');
				return false;
			}else{
			ids = ids.toString();
			var mySplitResult = ids.split("~");
			$('#example-one').hide();
			$('#example-three').hide();
			$.ajax({
				  url: "<?php echo plugins_url(); ?>/netriesdetail/change_cat.php",
				  data: 'mls='+mySplitResult[0],
				}).done(function(res) { 
					if(res == 'There is no records in this Agent.'){
						alert('There is no records in this Agent.');
						return false;
					}else{
						$('.list-wraps').html('Progressing..........');
						$('.list-wraps').html(res);
					}
				});
			}
		}
		
		function reassign(){
			var ids = $('#Select1').val();
			if(ids == null){
				alert('Please Select any one of the Agent!....');
				return false;
			}else{
			ids = ids.toString();
			var mySplitResult = ids.split("~");
			$('#example-one').hide();
			$('#example-three').hide();
			$.ajax({
				  url: "<?php echo plugins_url(); ?>/netriesdetail/reassign.php",
				  data: 'mls='+mySplitResult[0]+'&agent='+mySplitResult[1],
				}).done(function(res) { 
					if(res == 'There is no records in this Agent.'){
						alert('There is no records in this Agent.');
						return false;
					}else{
						$('.list-wraps').html('Progressing..........');
						$('.list-wraps').html(res);
					}
				});
			}
		}
		function all_list(){
			$('#example-one').hide();
			$('#example-three').hide();
			$('.list-wraps').html('Progressing..........');
			$.ajax({
				  url: "<?php echo plugins_url(); ?>/netriesdetail/list_all.php",
				  data: '',
				}).done(function(res) {
					$('.list-wraps').html(res);
				});
			}
    </script>
	
<div class="wrap">
<?php
					function generateSelect($name = '', $options = array()) {
						$html = '<select name="'.$name.'">';
						foreach ($options as $option => $value) {
							$html .= '<option value='.$value.'>'.$option.'</option>';
							}
							$html .= '</select>';
							return $html;
						}
					?>
	<div class="icon32" id="icon-options-general"><br/></div>
	<h2> Amerisale Listings </h2><br clear="all" />
	<div class="contes">
		<div id="example-one" >
				
			<div class="list-wrap">
			<h2> Add New Listings </h2><br clear="all" />
				<ul id="addnetres" >
					<form method="post" id="wp_netries_options">

						<?php
							global $wpdb;
							
							$sql = "select id,Name,agent_id,agent_license_no from  ".$wpdb->prefix."agents ";
							$tkeqry = $wpdb->get_results($sql);
						   //print_r($tkeqry);
							foreach($tkeqry as $key=>$slec){
								$sel[$slec->agent_license_no.' - '.$slec->Name] = $slec->agent_license_no;
							}
							 // echo "<pre>";print_r($sel);
							 ?>
							 <table class="form-table">
								<tr valign="top">
									<th scope="row"><?php _e('Select The Agent:', $this->localizationDomain); ?></th>
									<td><label><?php echo $html = generateSelect('agent', $sel); ?></label> </td>
								</tr>
							</table>
							
							<?php 
							$sql = "select city from  ".$wpdb->prefix."ntreislist group by city ";
							$tkeqry = $wpdb->get_results($sql);
							foreach($tkeqry as $key=>$slec){
								$city[$slec->city] = $slec->city;
							}
							?>
							
							 <table class="form-table">
								<tr valign="top">
									<th scope="row"><?php _e('Select The City:', $this->localizationDomain); ?></th>
									<td><label><?php echo $html = generateSelect('city', $city); ?></label> </td>
								</tr>
							</table>
					
							
							<?php
								$sql = "select county from  ".$wpdb->prefix."ntreislist group by county ";
								$tkeqry = $wpdb->get_results($sql);
								foreach($tkeqry as $key=>$slec){
									$country[$slec->county] = $slec->county;
								}
							?>
														
							<table class="form-table">
								<tr valign="top">
									<th scope="row"><?php _e('Select The Country:', $this->localizationDomain); ?></th>
									<td><label><?php echo $html = generateSelect('country', $country); ?></label> </td>
								</tr>
							</table>
				
							<table class="form-table">
								<tr valign="top">
									<th scope="row"><?php _e('Select The Catagory:', $this->localizationDomain); ?></th>
									<td><label>
									<select name="type">
									  <option>Residential</option>
									  <option>Commercial</option>
									  <option>Multi-Family</option>
									  <option>Lots and Acreage</option>
									</select></label> </td>
								</tr>
							</table>
							
							<p class="submit">
								<input type="submit" value="+ Add Listing" name="save" class="button-primary" />
							</p>
					</form>
				</ul>
			</div>
		</div>
		<br clear="all" />
		<br /><br />
		<?php
		/* $sql = "select id,Name,agent_id,agent_license_no from ".$wpdb->prefix."agents ";
		$tkeqry = $wpdb->get_results($sql);
		$agents_list = $agents =array();
		foreach($tkeqry as $a_mls)
		{
			$agents[] = $a_mls->agent_license_no;
			$agents_list[$a_mls->agent_license_no]['agent_id'] = $a_mls->agent_id;
			$agents_list[$a_mls->agent_license_no]['agent_license_no'] = $a_mls->agent_license_no;
			$agents_list[$a_mls->agent_license_no]['name'] = $a_mls->Name;
			$agents_list[$a_mls->agent_license_no]['id'] = $a_mls->id;
		}
		// echo "<pre>";print_r(array_filter($agents));
		$agents = implode(',',array_filter($agents));
		
		echo $sql1 = "select agentlist,MLS from ".$wpdb->prefix."ntreislist where agentlist in(".$agents.")";
		$mlslist = $wpdb->get_results($sql1);
		foreach($mlslist as $lists){
			$agents_list[$lists->agentlist]['MLS'] = $lists->MLS;
			$agents_list[$lists->agentlist]['agentlist'] = $lists->agentlist;
		}
		echo "COunt".count($agents_list);
		echo "<pre>";print_r($agents_list); */
		// echo $sql = "SELECT * FROM ".$wpdb->prefix."ntreislist where agentlist IN (select agent_license_no from ".$wpdb->prefix."agents where agent_license_no != '')";
		$sql = "SELECT A.agent_license_no,A.Name,A.agent_id,B.MLS,B.agentlist,B.is_manual_edit,B.expired_date
				FROM ".$wpdb->prefix."agents AS A
				LEFT JOIN ".$wpdb->prefix."ntreislist AS B
				ON A.agent_license_no=B.agentlist WHERE B.agentlist != ''";
		$tkeqry = $wpdb->get_results($sql);
		// echo "<pre>";print_r($tkeqry);
		
		/* foreach($tkeqry as $a_mls)
		{
			// if($a_mls['agentlist'] == $a_mls['agent_license_no']){
				echo "<pre>";print_r($a_mls);	
			// }
		} */
		?>
		<div id="example-two"  >
			<div class="list-wraps">
			<h2>Listings </h2><br clear="all" />
				<ul id="addnetres" >
				<select name="drop1" id="Select1" size="4" multiple="multiple" style="width: 400px; height: 400px;">
					<?php 
						/* $sql = "select id,Name,agent_id from ".$wpdb->prefix."agents ";
						$tkeqry = $wpdb->get_results($sql);
						foreach($tkeqry as $a_mls)
						{
							echo '<option value="'.$a_mls->agent_id.'">'.$a_mls->id." Agent ID:".$a_mls->id." - MLS #:".$a_mls->agent_id.'</option>';
						} */
						foreach($tkeqry as $a_mls)
						{ 
							if($a_mls->is_manual_edit == 1){
								echo '<option class="black" value="'.$a_mls->MLS.'~'.$a_mls->agent_id.'">'.$a_mls->agent_id." Agent ID:".$a_mls->agent_license_no." - MLS #:".$a_mls->MLS.'</option>';
							}else if ( date() < $a_mls->expired_date) {
								echo '<option class="red" value="'.$a_mls->MLS.'~'.$a_mls->agent_id.'">'.$a_mls->agent_id." Agent ID:".$a_mls->agent_license_no." - MLS #:".$a_mls->MLS.'</option>';
							}else if($a_mls->is_manual_edit == 0){
								echo '<option class="blue" value="'.$a_mls->MLS.'~'.$a_mls->agent_id.'">'.$a_mls->agent_id." Agent ID:".$a_mls->agent_license_no." - MLS #:".$a_mls->MLS.'</option>';
							}
						}
					?>
				</select>				
				</ul><br clear="all" /><br />
				<button type="button" onclick="edit_list();">View Listing!</button> 
				<!--<button type="button" onclick="sel_list();">View Listing!</button>-->
				<button type="button" onclick="edit_list();">Edit Listing!</button> 
				<button type="button" onclick="change_cat();">Change Category</button> 
				<button type="button" onclick="reassign();">Re-Assign</button> 
				<button type="button" onclick="all_list();">List All Listings</button> 
			</div>	
		</div>	
		
		<div id="example-three" >
		<div class="list-wrap1">
				<h2>Archives</h2><br clear="all" />
				<?php
				// ()
				$today = getdate();
				$date = $today['year']."-".$today['mon']."-".$today['mday'];
				//2012-05-04
					// echo $sql = "select agentlist,MLS from ".$wpdb->prefix."ntreislist where expired_date >= '".$date."' ";
					$sql = "SELECT A.agent_license_no,A.Name,A.agent_id,B.MLS,B.agentlist,B.is_manual_edit,B.expired_date
				FROM ".$wpdb->prefix."agents AS A
				LEFT JOIN ".$wpdb->prefix."ntreislist AS B
				ON A.agent_license_no=B.agentlist WHERE B.agentlist != '' AND B.expired_date <= '".$date."' ";
					$mlslist = $wpdb->get_results($sql);
					// var_dump($mlslist);
					if(!empty($mlslist)){
						foreach($mlslist as $key=>$archive){
							echo ($key+1).") MLS# ".$archive->MLS." Listing ID#".$archive->agentlist;
							echo "<br clear='all' />";
						}
					}else{
						
					}
				?>
			</div>		
		</div>		
	</div>
</div>

<?php
		}
	}
}
if (class_exists('WPAYnetress')) {
	$wp_netries = new WPAYnetress();
}

?>